let valores = [2, 3, 5, 2, 4, 2, 8, 5, 8]

const nuevo_valores = new Set(valores)

console.log(nuevo_valores)