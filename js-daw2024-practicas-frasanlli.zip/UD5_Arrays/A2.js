let letras = [];

letras.unshift("A","B","C")

letras.push("D","E")

letras.shift()
letras.pop()

console.log(letras)
