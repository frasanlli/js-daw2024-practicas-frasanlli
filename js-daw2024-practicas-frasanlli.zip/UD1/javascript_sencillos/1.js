let nombreUsuario = window.prompt("¿Cuál es tu nombre?");
window.alert("Hola " + nombreUsuario);
