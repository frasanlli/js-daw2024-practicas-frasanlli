const clavesEdades = new Map()

clavesEdades.set("Ana", 25)
clavesEdades.set("Luis", 30)
clavesEdades.set("María", 28)
clavesEdades.set("Carlos", 35)

clavesEdades.set("Luis", 61)

console.log(clavesEdades);
